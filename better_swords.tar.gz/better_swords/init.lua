dofile(minetest.get_modpath("better_swords").."/swords.lua")
dofile(minetest.get_modpath("better_swords").."/knives.lua")
dofile(minetest.get_modpath("better_swords").."/craftings.lua")

